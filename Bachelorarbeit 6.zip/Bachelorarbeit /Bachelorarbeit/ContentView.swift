//
//  ContentView.swift
//  Bachelorarbeit
//
//  Created by JT X on 12.10.20.
//



import SwiftUI

struct ContentView: View {
    
    @State var isLeftNav = false
    @State var show = false
    @State var showingProfile = false
    @EnvironmentObject var userData: UserData

    
    var profileButton: some View {
        Button(action: { self.showingProfile.toggle() }) {
            Image(systemName: "person.crop.circle")
                .imageScale(.large)
                .accessibility(label: Text("User Profile"))
                .padding()
        }
    }
    
    
    var body: some View {
        
        let service = NearbyService(displayName: userData.profile.username,userData)
        
        NavigationView{
            List{
                NavigationLink(destination:SpielleiterUI()
                                .environmentObject(service)
                ){
                    Text("Ich bin Spielleiter")
                }
                .frame(width: 200, height: 100)
                
                NavigationLink(destination:AufnahmeUI()
                                .environmentObject(AudioRecorder(service))
                                .environmentObject(service)
//                                .environmentObject(userData)
                ){
                    Text("Ich bin Mitspieler")
                    
                }
                .frame(width: 200, height: 100)
            }
            
            
            .navigationBarItems(trailing: profileButton)
            .sheet(isPresented:self.$showingProfile){
                ProfileHost()
                    .environmentObject(self.userData)
            }
            .onAppear{
                service.stopBrowser()
                service.stopAdvertising()
            }
        }
    }
}







struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(UserData())
    }
}




