//
//  SpielleiterUI.swift
//  Bachelorarbeit
//
//  Created by JT X on 01.11.20.
//



import Combine
import SwiftUI



struct SpielleiterUI: View {
    
    
    @EnvironmentObject var nearbyService: NearbyService
    

    static let goalFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .short
        return formatter
    }()
    


    var body: some View{
        
        List{
     
            Text("Datum und Zeit: \(self.nearbyService.sitzung.datum,formatter:Self.goalFormatter)")
        
            Spacer()
            Section(header:Text("Sitzungstitel")){
                TextField("Sitzungstitel", text: $nearbyService.sitzung.title).textFieldStyle(RoundedBorderTextFieldStyle())
            }
            Spacer()
            HStack {
                Button {
                    nearbyService.showBrowsesrController()
                } label: {
                    Text("Suchen")
                }
            }
            Spacer()
            NavigationLink(destination:AufnahmeUI()
                            .environmentObject(nearbyService)
                            .environmentObject(AudioRecorder(nearbyService))
            ){
            Text("Weiter")
            }
            
            
            
        }.onAppear{
            nearbyService.startBrowser()
        }
    
        
    }
    
}


struct SpielleiterUI_Previews: PreviewProvider {
    static var previews: some View {
        SpielleiterUI()

    }
}
