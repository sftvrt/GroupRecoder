//
//  UserData.swift
//  Bachelorarbeit
//
//  Created by JT X on 18.10.20.
//

import Combine
import SwiftUI


class UserData: ObservableObject {
    @Published var profile = Profile.default
}
